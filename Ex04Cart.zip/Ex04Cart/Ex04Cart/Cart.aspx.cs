﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// default using directives

namespace Ex04Cart
{
    public partial class Cart : System.Web.UI.Page
    {
        private CartItemList cart;

        protected void Page_Load(object sender, EventArgs e)
        {
            //retrieve cart object from session state on every postback
            cart = CartItemList.GetCart();
            // on initial page load, add cart items to list control
            if (!IsPostBack) this.DisplayCart();
        }

        private void DisplayCart()
        {
            //remove all current items from list control
            lstCart.Items.Clear();

            //loop through cart and add each items display value to the list
            for (int i = 0; i < cart.Count; i++)
            {
                lstCart.Items.Add(cart[i].Display());
            }
        }
        protected void btnRemove_Click(object sender, EventArgs e)
        {
            //if cart contains items and user has selected an item..
            if (cart.Count > 0)
            {
                if (lstCart.SelectedIndex > -1)
                {
                    //remove selected item from cart redisplay cart
                    cart.RemoveAt(lstCart.SelectedIndex);
                    this.DisplayCart();
                }
                else
                {
                    //if no item is selected, notify user
                    lblMessage.Text = "Please select the item to remove.";
                }
            }
        }

        protected void btnCheckOut_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "Sorry, that function hasnt been " + "implemented yet.";
        }

        protected void btnEmpty_Click(object sender, EventArgs e)
        {
            // if cart has items, clear both cart and list control
            if (cart.Count > 0)
            {
                cart.Clear();
                lstCart.Items.Clear();
            }
        }
    }
}